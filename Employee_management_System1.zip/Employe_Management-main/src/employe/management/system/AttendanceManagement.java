package employe.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

public class AttendanceManagement extends JFrame implements ActionListener {

    JComboBox<String> cEmpId;
    JTextField tDate, tStatus;
    JButton btnSave, btnView;
    
    AttendanceManagement() {
        setTitle("Attendance Management");
        setSize(400, 300);
        setLocation(450, 200);
        setLayout(null);

        JLabel lblTitle = new JLabel("Attendance Management", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitle.setBounds(50, 10, 300, 30);
        add(lblTitle);

        JLabel lblEmpId = new JLabel("Employee ID:");
        lblEmpId.setBounds(50, 60, 100, 25);
        add(lblEmpId);

        cEmpId = new JComboBox<>();
        loadEmployeeIds();
        cEmpId.setBounds(160, 60, 150, 25);
        add(cEmpId);

        JLabel lblDate = new JLabel("Date (yyyy-mm-dd):");
        lblDate.setBounds(50, 100, 130, 25);
        add(lblDate);

        tDate = new JTextField();
        tDate.setBounds(190, 100, 120, 25);
        add(tDate);

        JLabel lblStatus = new JLabel("Status (Present/Absent):");
        lblStatus.setBounds(50, 140, 160, 25);
        add(lblStatus);

        tStatus = new JTextField();
        tStatus.setBounds(210, 140, 100, 25);
        add(tStatus);

        btnSave = new JButton("Save Attendance");
        btnSave.setBounds(50, 190, 150, 30);
        btnSave.addActionListener(this);
        add(btnSave);

        btnView = new JButton("View Attendance");
        btnView.setBounds(210, 190, 130, 30);
        btnView.addActionListener(this);
        add(btnView);
    }

    void loadEmployeeIds() {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT empid FROM employee");
            while (rs.next()) {
                cEmpId.addItem(rs.getString("empid"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Loading IDs: " + e);
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnSave) {
            String empId = (String) cEmpId.getSelectedItem();
            String date = tDate.getText();
            String status = tStatus.getText();

            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement pst = con.prepareStatement("INSERT INTO attendance VALUES(?, ?, ?)");
                pst.setString(1, empId);
                pst.setString(2, date);
                pst.setString(3, status);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Attendance Saved Successfully!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e);
            }
        } else if (ae.getSource() == btnView) {
            new ViewAttendance().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new AttendanceManagement().setVisible(true);
    }
}
