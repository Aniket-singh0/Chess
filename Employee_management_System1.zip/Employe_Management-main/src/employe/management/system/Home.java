package employe.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Home extends JFrame implements ActionListener {
    
    JButton view, add, remove, update;
    JButton attendance, viewAttendance, fees; // नए बटन
    
    Home() {
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/home.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1120, 630, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1050, 630);
        add(image);

        JLabel heading = new JLabel("EMPLOYEE MANAGEMENT SYSTEM");
        heading.setBounds(650, 20, 400, 40);
        heading.setFont(new Font("Raleway", Font.BOLD, 25));
        image.add(heading);

        add = new JButton("ADD EMPLOYEE");
        add.setBounds(650, 80, 150, 40);
        add.addActionListener(this);
        image.add(add);

        view = new JButton("VIEW EMPLOYEE");
        view.setBounds(820, 80, 150, 40);
        view.addActionListener(this);
        image.add(view);

        update = new JButton("UPDATE EMPLOYEE");
        update.setBounds(650, 140, 150, 40);
        update.addActionListener(this);
        image.add(update);

        remove = new JButton("REMOVE EMPLOYEE");
        remove.setBounds(820, 140, 150, 40);
        remove.addActionListener(this);
        image.add(remove);

        // 🔹 Attendance Button
        attendance = new JButton("MARK ATTENDANCE");
        attendance.setBounds(650, 200, 150, 40);
        attendance.addActionListener(this);
        image.add(attendance);

        // 🔹 View Attendance Button
        viewAttendance = new JButton("VIEW ATTENDANCE");
        viewAttendance.setBounds(820, 200, 150, 40);
        viewAttendance.addActionListener(this);
        image.add(viewAttendance);

        // 🔹 Fees Management Button
        fees = new JButton("FEES / SALARY");
        fees.setBounds(735, 260, 150, 40);
        fees.addActionListener(this);
        image.add(fees);

        setSize(1120, 630);
        setLocation(250, 100);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            setVisible(false);
            new AddEmployee();
        } else if (ae.getSource() == view) {
            setVisible(false);
            new ViewEmployees();
        } else if (ae.getSource() == update) {
            setVisible(false);
            new ViewEmployees();
        } else if (ae.getSource() == remove) {
            setVisible(false);
            new RemoveEmployee();
        } else if (ae.getSource() == attendance) {
            // ✅ Attendance Management Open
            new employe.management.system.AttendanceManagement().setVisible(true);
        } else if (ae.getSource() == viewAttendance) {
            // ✅ View Attendance Open
            new employe.management.system.ViewAttendance().setVisible(true);
        } else if (ae.getSource() == fees) {
            // ✅ Fees Management Open
            new employe.management.system.FeesManagement().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Home();
    }
}
