package employe.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewAttendance extends JFrame {
    
    JTable table;
    
    ViewAttendance() {
        setTitle("View Attendance Records");
        setSize(500, 400);
        setLocation(450, 200);
        setLayout(new BorderLayout());

        String[] columnNames = {"Employee ID", "Date", "Status"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);
        
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM attendance ORDER BY date DESC");
            
            while (rs.next()) {
                String empId = rs.getString("emp_id");
                String date = rs.getString("date");
                String status = rs.getString("status");
                model.addRow(new Object[]{empId, date, status});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e);
        }

        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        new ViewAttendance().setVisible(true);
    }
}
