package employe.management.system;

import employe.management.system.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class FeesManagement extends JFrame implements ActionListener {

    JComboBox<String> cEmpId;
    JTextField tMonth, tSalary;
    JButton btnCalc, btnSave, btnView;

    FeesManagement() {
        setTitle("Salary/Fee Management");
        setSize(450, 350);
        setLocation(450, 200);
        setLayout(null);

        JLabel lblTitle = new JLabel("Fees / Salary Management", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitle.setBounds(30, 10, 380, 30);
        add(lblTitle);

        JLabel lblEmpId = new JLabel("Employee ID:");
        lblEmpId.setBounds(50, 60, 100, 25);
        add(lblEmpId);

        cEmpId = new JComboBox<>();
        loadEmployeeIds();
        cEmpId.setBounds(160, 60, 150, 25);
        add(cEmpId);

        JLabel lblMonth = new JLabel("Month (yyyy-mm):");
        lblMonth.setBounds(50, 100, 120, 25);
        add(lblMonth);

        tMonth = new JTextField();
        tMonth.setBounds(170, 100, 120, 25);
        add(tMonth);

        JLabel lblSalary = new JLabel("Base Salary:");
        lblSalary.setBounds(50, 140, 100, 25);
        add(lblSalary);

        tSalary = new JTextField();
        tSalary.setBounds(160, 140, 100, 25);
        add(tSalary);

        btnCalc = new JButton("Calculate");
        btnCalc.setBounds(50, 190, 120, 30);
        btnCalc.addActionListener(this);
        add(btnCalc);

        btnSave = new JButton("Save Salary");
        btnSave.setBounds(200, 190, 120, 30);
        btnSave.addActionListener(this);
        add(btnSave);

        btnView = new JButton("View Salary");
        btnView.setBounds(120, 240, 150, 30);
        btnView.addActionListener(this);
        add(btnView);
    }

    void loadEmployeeIds() {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT empId FROM employee");
            while (rs.next()) {
                cEmpId.addItem(rs.getString("empId"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Loading IDs: " + e);
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnCalc) {
            String empId = (String) cEmpId.getSelectedItem();
            String month = tMonth.getText();
            double baseSalary = Double.parseDouble(tSalary.getText());
            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement pst = con.prepareStatement(
                    "SELECT COUNT(*) AS present_days FROM attendance WHERE emp_Id=? AND status='Present' AND date LIKE ?"
                );
                pst.setString(1, empId);
                pst.setString(2, month + "%");
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    int present = rs.getInt("present_days");
                    double salary = (baseSalary / 30) * present;
                    JOptionPane.showMessageDialog(null, "Total Salary for " + month + " = ₹" + salary);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e);
            }
        } else if (ae.getSource() == btnSave) {
            try {
                String empId = (String) cEmpId.getSelectedItem();
                String month = tMonth.getText();
                double baseSalary = Double.parseDouble(tSalary.getText());

                Connection con = DBConnection.getConnection();
                PreparedStatement pstCount = con.prepareStatement(
                    "SELECT COUNT(*) AS present_days FROM attendance WHERE emp_Id=? AND status='Present' AND date LIKE ?"
                );
                pstCount.setString(1, empId);
                pstCount.setString(2, month + "%"); 
                ResultSet rs = pstCount.executeQuery();

                int presentDays = 0;
                if (rs.next()) presentDays = rs.getInt("present_days");

                double salaryAmount = (baseSalary / 30) * presentDays;

                PreparedStatement pstInsert = con.prepareStatement(
                    "INSERT INTO salary(empId, month, year, totalDays, presentDays, salaryAmount) VALUES (?, ?, ?, ?, ?, ?)"
                );
                pstInsert.setString(1, empId);
                String[] parts = month.split("-");
                pstInsert.setString(2, parts[1]); // month
                pstInsert.setInt(3, Integer.parseInt(parts[0])); // year
                pstInsert.setInt(4, 30);
                pstInsert.setInt(5, presentDays);
                pstInsert.setDouble(6, salaryAmount);
                pstInsert.executeUpdate();

                JOptionPane.showMessageDialog(null, "Salary saved successfully!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error saving salary: " + e);
            }
        } else if (ae.getSource() == btnView) {
            try {
                Connection con = DBConnection.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT * FROM salary");
                
                JTable table = new JTable();
                table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
                JScrollPane jsp = new JScrollPane(table);
                JFrame f = new JFrame("Salary Records");
                f.setSize(600, 400);
                f.add(jsp);
                f.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error fetching salary: " + e);
            }
        }
    }

    public static void main(String[] args) {
        new FeesManagement().setVisible(true);
    }
}
